#include <stdio.h>
#include <graphics.h>
#include <stdlib.h>
#include <math.h>
#define pi 3.14;

float x1,x2,yy1,yy2;
int xemax,yemax;

int xe(float x)
 // normalizarea coocdonatei x
{return((int) floor((x-x1)/(x2-x1)*xemax));}

int ye(float y)
 // normalizarea coocdonatei y
{return((int) floor((yy2-y)/(yy2-yy1)*yemax));}

void axe()
{setcolor(15);
 line(xe(x1),ye(0),xe(x2),ye(0));
 line(xe(0),ye(yy1),xe(0),ye(yy2));
 outtextxy(xe(0)-15,ye(0)-15,"O");
 outtextxy(xe(x2)-20,ye(0)-20,"x");
   outtextxy(xe(x2)-6,ye(0)-7,">");
 outtextxy(xe(0)-15,ye(yy2)+15,"y");
  outtextxy(xe(0)-1,ye(yy2)+1,"^");

}



void grafic() {
}

int main()
{int gd,gm;
 
 printf("Limitele domeniului orizontal:\n");
 printf("x1="); scanf("%f",&x1);
 printf("x2="); scanf("%f",&x2);
 printf("Limitele domeniului vertical:\n");
 printf("y1="); scanf("%f",&yy1);
 printf("y2="); scanf("%f",&yy2);
 initwindow(800,600, "Exemplu lab 1",200,200); 
 xemax=getmaxx(); yemax=getmaxy();
 axe(); 
 setcolor(YELLOW);
 grafic();

 getchar(); getchar();
 closegraph();
 return 0;
}
 
